<?php
// Supabase API credentials
$supabaseUrl = 'https://cixmlhamgywcrpeqotup.supabase.co';
$supabaseApiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpeG1saGFtZ3l3Y3JwZXFvdHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTY0NTkyODksImV4cCI6MjAzMjAzNTI4OX0.5xjAlJ2jtQgs38DexLC-4H89eLER6eWUAA2fWm8vyVU';

// Function to fetch data from the Market table
function fetchMarketData() {
    global $supabaseUrl, $supabaseApiKey;

    $url = $supabaseUrl . '/rest/v1/Market?select=*';
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . $supabaseApiKey,
        'Authorization: Bearer ' . $supabaseApiKey,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Fetch the data
$marketData = fetchMarketData();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farmers Prime</title>
    <link rel="stylesheet" href="slyza.css">
  
</head>
<body>

    <!-- Side Menu -->
    <div id="menu">
        <div class="logo">
        <img src="logo.png" alt="Farmers Prime Logo" style="width: 200px; height: auto;">
        </div>
        <ul class="items">
            <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="#"><i class="fas fa-info-circle"></i> About Us</a></li>
            <li><a href="#"><i class="fas fa-phone"></i> Contact</a></li>
        </ul>
    </div>

    <!-- Main Interface -->
    <div id="interface">
        <div class="navigation">
            <div class="n1">
                <div id="menu-btn"><i class="fas fa-bars"></i></div>
                <div class="search">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search livestock...">
                </div>
            </div>
            <div class="profile">
                <i class="fas fa-user-circle"></i>
                <img src="profile.jpg" alt="User Profile">
            </div>
        </div>

        <!-- Page Title -->
        <div class="i-name">
            <h1>Farmers Market</h1>
        </div>

        <!-- Livestock Cards -->
        <div class="values">
            <?php if (!empty($marketData)): ?>
                <?php foreach ($marketData as $item): ?>
                    <div class="val-box" onclick="showDetails(`<?php echo addslashes(json_encode($item)); ?>`)">
                        <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                        <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                        <span>Price: N$<?php echo number_format($item['price'], 2); ?></span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No data available.</p>
            <?php endif; ?>
        </div>
    </div>

</body>
</html>
