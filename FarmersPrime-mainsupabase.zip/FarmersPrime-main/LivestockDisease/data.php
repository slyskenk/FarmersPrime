<?php
// Supabase API credentials
$supabaseUrl = 'https://cixmlhamgywcrpeqotup.supabase.co';
$supabaseApiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpeG1saGFtZ3l3Y3JwZXFvdHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTY0NTkyODksImV4cCI6MjAzMjAzNTI4OX0.5xjAlJ2jtQgs38DexLC-4H89eLER6eWUAA2fWm8vyVU';

// Function to insert data into the DiseaseReports table
function insertDiseaseReport($data) {
    global $supabaseUrl, $supabaseApiKey;

    $url = $supabaseUrl . '/rest/v1/DiseaseReports';
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . $supabaseApiKey,
        'Authorization: Bearer ' . $supabaseApiKey,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Handle form submission
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = [
        'disease_name' => $_POST['disease_name'],
        'symptoms' => $_POST['symptoms'],
        'severity' => $_POST['severity'],
        'status' => $_POST['status'],
        'name' => $_POST['name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
    ];

    $result = insertDiseaseReport($data);

    if ($result) {
        $message = "Data inserted successfully!";
    } else {
        $message = "Data inserted successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Report a Disease</title>
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background-color: #ffffff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            max-width: 450px;
            width: 100%;
            position: relative;
        }
        .back-btn {
            display: inline-block;
            background-color: #cccccc;
            color: #333;
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            color: #555;
            margin-bottom: 6px;
            display: block;
        }
        input[type="text"], input[type="email"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .submit-btn {
            background-color: #3498db;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            text-align: center;
        }
        .submit-btn:hover {
            background-color: #2980b9;
        }
        .alert {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            background-color: #4caf50;
            color: white;
            padding: 15px;
            text-align: center;
            font-weight: bold;
            border-radius: 8px;
            margin: 10px;
            opacity: 0;
            transition: opacity 0.5s;
        }
        .alert.visible {
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <a href="javascript:history.back()" class="back-btn">← Back</a>
        <h2>Report a Disease</h2>
        
        <?php if ($message): ?>
            <div class="alert" id="alert"><?php echo $message; ?></div>
            <script>
                // Display alert message and reset form
                document.addEventListener("DOMContentLoaded", function() {
                    const alertBox = document.getElementById("alert");
                    alertBox.classList.add("visible");
                    
                    // Hide the alert box after 4 seconds
                    setTimeout(() => {
                        alertBox.classList.remove("visible");
                    }, 4000);

                    // Reset the form if data was inserted successfully
                    <?php if ($message == "Data inserted successfully!"): ?>
                        document.querySelector("form").reset();
                    <?php endif; ?>
                });
            </script>
        <?php endif; ?>
        
        <form method="POST">
            <label for="disease_name">Disease Name:</label>
            <input type="text" id="disease_name" name="disease_name" required>

            <label for="symptoms">Symptoms:</label>
            <textarea id="symptoms" name="symptoms" rows="4" required></textarea>

            <label for="severity">Severity:</label>
            <input type="text" id="severity" name="severity">

            <label for="status">Status:</label>
            <input type="text" id="status" name="status">

            <label for="name">Your Name:</label>
            <input type="text" id="name" name="name">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email">

            <label for="phone">Phone:</label>
            <input type="number" id="phone" name="phone">

            <button type="submit" class="submit-btn">Submit</button>
        </form>
    </div>
</body>
</html>
