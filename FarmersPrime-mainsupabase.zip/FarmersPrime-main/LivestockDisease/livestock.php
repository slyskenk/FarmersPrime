<?php
// Supabase API credentials
$supabaseUrl = 'https://cixmlhamgywcrpeqotup.supabase.co';
$supabaseApiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpeG1saGFtZ3l3Y3JwZXFvdHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTY0NTkyODksImV4cCI6MjAzMjAzNTI4OX0.5xjAlJ2jtQgs38DexLC-4H89eLER6eWUAA2fWm8vyVU';

// Function to fetch disease report data from the DiseaseReports table
function fetchDiseaseReportsData() {
    global $supabaseUrl, $supabaseApiKey;

    $url = $supabaseUrl . '/rest/v1/DiseaseReports?select=*'; // Query to get all rows
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . $supabaseApiKey,
        'Authorization: Bearer ' . $supabaseApiKey,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Fetch data from the DiseaseReports table
$diseaseReports = fetchDiseaseReportsData();

// Convert the PHP array to a JavaScript array for use in the frontend
$diseaseReports_json = json_encode($diseaseReports);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <title>Livestock</title>
</head>
<body>
    <section id="header">
        <button class="openbtn" onclick="openNav()">☰</button>
        <div id="mySidebar" class="sidebar">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
            <a href="diseaseRep/diseaseReporting.html">Report Disease</a>
            <a href="health/health.html" onclick="showContent('resources')">Health Resources</a>
        </div>
        <div>
            <ul id="navbar">
                <li><a href="homePage.html"> Home</a></li>
                <li><a class="active" href="livestockDisease.html">Disease</a></li>
                <li><a href="marketPage.html">Market</a></li>
                <li><a href="Login.html">Login</a></li>
                <li><a href="contactdetails.html">Contact</a></li>
            </ul>
        </div>
    </section>

    <div class="content"></div>

    <section id="dd">
        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Search diseases...">
            <button id="searchButton" onclick="searchDiseases()">Search</button>
            <a href="data.php"><button id="searchButton">Add</button></a>
        </div>

        <div class="container">
            <div class="disease-container" id="diseaseContainer"></div>
        </div>
    </section>

    <script src="script.js"></script>

    <script>
        // Pass the PHP data to JavaScript
        const diseaseReports = <?php echo $diseaseReports_json; ?>;

        // Function to create the disease report card
        function createDiseaseCard(disease) {
            const card = document.createElement('div');
            card.className = 'disease-card';
            card.innerHTML = `
                <div class="card-header">
                    <h3>${disease.disease_name || 'Unknown Disease'}</h3>
                </div>
                <p><strong>Symptoms:</strong> ${disease.symptoms || 'No symptoms provided'}</p>
                <p><strong>Severity:</strong> ${disease.severity || 'No severity provided'}</p>
                <p><strong>Status:</strong> ${disease.status || 'No status provided'}</p>
                <p><strong>Reported by:</strong> ${disease.name || 'Anonymous'}</p>
                <p><strong>Email:</strong> ${disease.email || 'No email provided'}</p>
                <p><strong>Phone:</strong> ${disease.phone || 'No phone provided'}</p>
            `;
            return card;
        }

        // Function to render disease report cards
        function renderDiseaseReports(reportsToShow) {
            const container = document.getElementById('diseaseContainer');
            container.innerHTML = ''; // Clear existing cards
            reportsToShow.forEach(disease => {
                container.appendChild(createDiseaseCard(disease));
            });
        }

        // Initially render all disease reports
        renderDiseaseReports(diseaseReports);

        // Function to search diseases (optional)
        function searchDiseases() {
            const searchQuery = document.getElementById('searchInput').value.toLowerCase();
            const filteredReports = diseaseReports.filter(report =>
                report.disease_name.toLowerCase().includes(searchQuery) ||
                report.symptoms.toLowerCase().includes(searchQuery) ||
                report.status.toLowerCase().includes(searchQuery)
            );
            renderDiseaseReports(filteredReports);
        }

        // Function to open sidebar menu
        function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
        }

        // Function to close sidebar menu
        function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
        }
    </script>
</body>
</html>
