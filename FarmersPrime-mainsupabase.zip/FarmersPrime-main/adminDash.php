<?php
// Supabase API credentials
$supabaseUrl = 'https://cixmlhamgywcrpeqotup.supabase.co';
$supabaseApiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNpeG1saGFtZ3l3Y3JwZXFvdHVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTY0NTkyODksImV4cCI6MjAzMjAzNTI4OX0.5xjAlJ2jtQgs38DexLC-4H89eLER6eWUAA2fWm8vyVU';

// Function to fetch data from the public.Users table
function fetchUsersData() {
    global $supabaseUrl, $supabaseApiKey;

    $url = $supabaseUrl . '/rest/v1/public.Users';
    $headers = [
        'Content-Type: application/json',
        'apikey: ' . $supabaseApiKey,
        'Authorization: Bearer ' . $supabaseApiKey,
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Fetch the data
$users = fetchUsersData();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="author" content="Slysken Kakuva">
    <meta name="description" content="This page contains info about Farmers Prime Admin Dashboard.">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="slyza.css" type="text/css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/b785009a9c.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">
</head>

<body>
    <header class="header">
        <div class="logo">LOGO</div>
        <nav class="nav-menu">
            <li><i class="fa-solid fa-chart-simple"></i><a href="index.html">Homepage</a></li>
            <li><i class="fa-brands fa-uikit"></i><a href="adminDash.html">Dashboard</a></li>
            <li><i class="fa-solid fa-table"></i><a href="#">Market</a></li>
            <li><i class="fa-solid fa-disease"></i><a href="LivestockDisease/livestockDi.html">Disease</a></li>
            <li><i class="fa-solid fa-file-waveform"></i><a href="LivestockDisease/diseaseRep/diseaseReporting.html">Report</a></li>
            <li><i class="fa-solid fa-box"></i><a href="#">Sign In</a></li>
            <li><i class="fa-solid fa-clipboard-question"></i><a href="#">About Us</a></li>
        </nav>
        <div class="user-menu">
            <div class="admin-profile" id="adminProfile">
                <img src="/AdminDash/images/1.jpg" alt="Admin avatar" width="32" height="32">
                <span>English</span>
            </div>
        </div>
    </header>

    <main class="main-content">
        <section class="trending-section">
            <h2>New and Trending</h2>
            <div class="trending-cards">
                <div class="trending-card">
                    <h3>Farmer Numbers</h3>
                    <p>405</p>
                </div>
                <div class="trending-card">
                    <h3>Livestock Sold Today</h3>
                    <p>3</p>
                </div>
                <div class="trending-card">
                    <h3>Market Insights</h3>
                    <p>Average</p>
                </div>
            </div>
        </section>

        <section class="dashboard-table">

<div class="search-bar">
    <input type="text" placeholder="Search">
    <button class="search-btn">Search</button> <!-- Added Search Button -->
</div>

<!-- Table with Edit Icon in Each Row -->
<table>
    <thead>
        <tr>
            <th>Rank</th>
            <th>Profile</th>
            <th>Name</th>
            <th>Category</th>
            <th>Rating</th>
            <th>Source</th>
            <th>Action</th> <!-- New column for Edit Icon -->
        </tr>
    </thead>
    <tbody id="userTableBody">
        <?php foreach ($users as $user): ?>
            <tr class="user-row" data-id="<?php echo htmlspecialchars($user['id']); ?>" data-name="<?php echo htmlspecialchars($user['name']); ?>" data-specialization="<?php echo htmlspecialchars($user['specialization']); ?>" data-rating="<?php echo htmlspecialchars($user['rating'] ?? 'N/A'); ?>" data-avatar="<?php echo htmlspecialchars($user['avatar_url'] ?? '/AdminDash/images/1.jpg'); ?>">
                <td><?php echo htmlspecialchars($user['role']); ?></td>
                <td><img src="<?php echo htmlspecialchars($user['avatar_url'] ?? '/AdminDash/images/1.jpg'); ?>" alt="<?php echo htmlspecialchars($user['name']); ?>" class="table-avatar"></td>
                <td><?php echo htmlspecialchars($user['name']); ?></td>
                <td><?php echo htmlspecialchars($user['specialization']); ?></td>
                <td><?php echo htmlspecialchars($user['rating'] ?? 'N/A'); ?></td>
                <td>Supabase</td>
                <td><button class="edit-btn"><i class="fa-solid fa-pen"></i> Edit</button></td> <!-- Edit Button -->
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</div>
        </section>
    </main>

    <!-- Popup Modal -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <span id="closeModal" class="close">&times;</span>
            <h2>User Details</h2>
            <p><strong>Rank:</strong> <span id="modalRank"></span></p>
            <p><strong>Name:</strong> <span id="modalName"></span></p>
            <p><strong>Category:</strong> <span id="modalCategory"></span></p>
            <p><strong>Rating:</strong> <span id="modalRating"></span></p>
            <p><strong>Avatar:</strong> <img id="modalAvatar" src="" alt="Avatar" width="100" height="100"></p>
        </div>
    </div>

    <script>
        // Get modal elements
        const modal = document.getElementById('userModal');
        const closeModal = document.getElementById('closeModal');

        // Handle row click to show popup
        document.querySelectorAll('.user-row').forEach(row => {
            row.addEventListener('click', function() {
                const role = this.getAttribute('data-role');
                const name = this.getAttribute('data-name');
                const specialization = this.getAttribute('data-specialization');
                const rating = this.getAttribute('data-rating');
                const avatar = this.getAttribute('data-avatar');

                // Populate modal with row data
                document.getElementById('modalRank').textContent = role;
                document.getElementById('modalName').textContent = name;
                document.getElementById('modalCategory').textContent = specialization;
                document.getElementById('modalRating').textContent = rating;
                document.getElementById('modalAvatar').src = avatar;

                // Show the modal
                modal.classList.add('show');
            });
        });

        // Close modal when the close button is clicked
        closeModal.onclick = function() {
            modal.classList.remove('show');
        };

        // Close modal when clicked outside the modal content
        window.onclick = function(event) {
            if (event.target === modal) {
                modal.classList.remove('show');
            }
        };
    </script>
</body>

</html>
